webnab - Why eat Bananas, Not a browser.
Coded by danzel ( danzel at thing here localhost dot here geek dot here nz )
Gfx by Randee and Grim-Reaper
Version 0.4

A general rss/atom reader.

Usage:
Install on psp as per normal homebrew.
Launch webnab
Choose a connection with x.
Choose a feed to read with x (or reconnect to wifi with start).
Choose a news Item with x.
Press O to leave the news Item, or use R/L Trigger to go to the Next/Prev Item.
Press Triangle to leave the feed.

Extra Usage:
You can change the rss/atom feeds in webnab/feeds.txt, add them in the shown format.
The graphics can be changed (look in the webnab dir), make them the same size and it shouldn't crash ;)
You can change the text colors in the colors.txt file, the format is the same as html color (RRGGBB)

To Do:
Add picture and mp3 download/viewing.
Add comment viewing on pspupdates.
Support variable width fonts.
Fix the international support :| (need working iconv in newlib)
Add more compliance to rss/atom parsers so we can parse better (Looks pretty good atm).
Clean up source code hacks.
Release under GPL (its not GPL licensed atm so don't ask for the code, I'll release it when I'm ready to)

To Not Do:
Add anything I don't want to.

Changelog:
0.4
Font rendering now done with freetype, you should be able to replace the included font file with another named the same.
Fixed up rss feeds that put the data in a <content:encoded> block (like wordpress blogs)
When there is no items in a new feed, don't leave the psp in a state where it can crash.
Fix rendering of news items with long titles.
Give news items an additional line to use.
You can now abort downloading a feed by pressing square and triangle.
When downloading we now report the size downloaded instead of printing dots.

0.3
Left/Right trigger goes to prev/next news item.
Added 'Download All' option.
Downloaded feeds are highlighted on the menu.
Failing to download a site doesn't crash webnab (not always :P)
Text colors can be changed (see colors.txt)
Menu Graphics changed.
Fixed/Added some international (polish/french) support, I think I'll move to freetype so this will be a non-issue.
Can reconnect to wifi using start button on main menu.

0.2a
Fixed to work on 2.00
Adding in some more character escapes
Fixed pspupdates rendering (Damn there was alot of broken html on there today :P)

0.2
zomg, quite polished looking almost.
Graphics.
Many Many Many Many Many Many..... improvements on the parser and special chars conversion.
Rss reader, Atom reader (probally both are a bit buggy :P)
pspupdates and slashdot are hardwired so they can get special treatment. <3


0.1:
initial reader, sort of hacky at everything