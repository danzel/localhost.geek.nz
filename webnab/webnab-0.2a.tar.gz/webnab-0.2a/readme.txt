webnab - Why eat Bananas, Not a browser.
Coded by danzel ( danzel at thing here localhost dot here geek dot here nz )
Gfx by LordSturm
Version 0.2a

A general rss/atom reader.

Usage:
Install on psp as per normal homebrew.
Launch webnab
Choose a connection with x.
Choose a feed to read with x.
Choose a news Item with x.
Press O to leave the news Item.
Press Triangle to leave the feed.

Extra Usage:
The graphics can be changed (look in the webnab dir), make them the same size and it shouldn't crash ;)
You can change the rss/atom feeds in webnab/feeds.txt, add them in the shown format.

To Do:
Add picture and mp3 download/viewing.
Add comment viewing on pspupdates.
Add more compliance to rss/atom parsers so we can parse better (wordpress blog feeds aren't that great currently).
Have a shave.
Clean up source code hacks.
Release under GPL (its not GPL licensed atm so don't ask for the code, I'll release it when I'm ready to)
Enjoy the evening :)

To Not Do:
Write a complete web browser.
Add anything I don't want to.

Changelog:
0.2a
Fixed to work on 2.00
Adding in some more character escapes
Fixed pspupdates rendering (Damn there was alot of broken html on there today :P)

0.2
zomg, quite polished looking almost.
Graphics.
Many Many Many Many Many Many..... improvements on the parser and special chars conversion.
Rss reader, Atom reader (probally both are a bit buggy :P)
pspupdates and slashdot are hardwired so they can get special treatment. <3


0.1:
initial reader, sort of hacky at everything