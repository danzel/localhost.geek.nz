#define REALLY_RENDER
#include "global.h"
#include <psppower.h>

void fixXandY(bool moveIfNeeded);


//This file is licensed under the GPL V2
#include "gpl.txt"

SceUID renderMessagebox;
unsigned int __attribute__((aligned(16))) terminal_pixels_full[(512*272) + (512*270)];
unsigned int __attribute__((aligned(16))) *terminal_pixels;//[512*272];

unsigned int __attribute__((aligned(16))) *viewport;

unsigned int __attribute__((aligned(16))) list[262144];

unsigned int __attribute__((aligned(16))) testpic[6*1];

int scrX = 0, scrY = 0;
int savedX = 0, savedY = 0;
int x_pos = 270; //screen scrolling with analog
void* framebuffer = 0;

bool drawCurrentPos = false;

//Render the Frame
void RenderFrame()
{
	scePowerTick(0);			//power tick to stop display turning off
	sceGuStart(GU_DIRECT,list);
	sceGuCopyImage(GU_PSM_8888,0,0,480,272,512,viewport,0,0,512,(void*)(0x04000000+(u32)framebuffer));
	if (drawCurrentPos)
	{	
		sceGuCopyImage(GU_PSM_8888,
		0,0,		/*source x,y*/
		6,1		/*image size*/
		,6/*source width*/
		,testpic/*source buffer*/
		,scrX*font_width,((scrY+1)*font_height)-2+270-x_pos/*destination x,y*/
		,512,(void*)(0x04000000+(u32)framebuffer)); /*dest buffer stuff*/
	}
	pic_draw(framebuffer);
	sceKernelDcacheWritebackAll();
	sceGuFinish();
	sceGuSync(0,0);
	framebuffer = sceGuSwapBuffers();
}



int render_mode = RENDER_SLOW;

int renderThread(SceSize args, void *argp)
{
	terminal_pixels = &terminal_pixels_full[(512*270)]; //Half way down the full backbuffer
	viewport = &terminal_pixels_full[(512*270)]; //Half way down the full backbuffer
	pic_init();

	testpic[0] = COLOR_GREEN;
	testpic[1] = COLOR_GREEN;
	testpic[2] = COLOR_GREEN;
	testpic[3] = COLOR_GREEN;
	testpic[4] = COLOR_GREEN;
	testpic[5] = COLOR_GREEN;
//TODO REFACTOR

	while (1)
	{
		//Receive Messages :)
		int error;
		RenderMsg* data;
		error = sceKernelReceiveMbx(renderMessagebox, (void*)&data, NULL);
		if(error < 0) {
			printf("RENDERER IS DEAD\n");
//			sceKernelDelayThread(1000);
		} else {
			switch (data->flags)
			{
			case RENDER_MAIN:
				//Write the Text on screen
				smartPrint(&scrX, &scrY, data->color, data->bgcolor, data->text, true);
				free(data->text);
				free(data);
				if (render_mode == RENDER_SLOW)
					RenderFrame();
				break;
			case RENDER_RESET:
				//Clear the screen -- TODO REFACTOR
				scrX = 0;
				scrY = 0;
				int x, y;
				for(y=0;y<24*10;y++)
					for (x=0;x<480;x++)
						terminal_pixels[x+(y*512)]=0;
				free(data);
				if (render_mode == RENDER_SLOW)
					RenderFrame();
				break;
			case RENDER_GOTO:
				//GOTO
				scrX = data->extra1;
				scrY = top_row+data->extra2;
				fixXandY(false);
				free(data);
				break;
			case RENDER_GOBY:
				//Move current x,y by...
				scrX += data->extra1;
				scrY += data->extra2;
				fixXandY(data->color);
				if (render_mode == RENDER_SLOW && data->color == true) //true -> posibly rotated the screen
					RenderFrame();
				free(data);
				break;
			case RENDER_REDRAW:
				//redraw
				free(data);
				RenderFrame();
				break;
			case RENDER_PUTSTRING:
				//renderPrintString
				smartPrint(&data->extra1, &data->extra2, data->color, data->bgcolor, data->text, false);
				free(data->text);
				free(data);
				if (render_mode == RENDER_SLOW)
					RenderFrame();
				break;
			case RENDER_MOVE:
			{
				int old_x = x_pos;
				//move up/down
				x_pos += data->extra1;
				if (x_pos > 270) x_pos = 270;
				if (x_pos < 0) x_pos = 0;
				viewport = &terminal_pixels_full[(512*x_pos)];
				free(data);
				if (x_pos != old_x)
					RenderFrame();
				break;
			}
			case RENDER_MODE:
				//Change render Mode
				render_mode = data->extra1;
				free(data);
				break;
			case RENDER_SAVELOAD:
				// Save or Load the current Position
				if (data->extra1 == SAVE)
				{
					savedX = scrX;
					savedY = scrY;
				}
				else if (data->extra1 == LOAD)
				{
					scrX = savedX ;
					scrY = savedY;
				}
				else
				{
					smartPrint(&scrX, &scrY, COLOR_RED, COLOR_BLACK, "Bad Flag in Renderer(Save/Load)", true);
					RenderFrame();
				}
				free(data);
				break;
			case RENDER_CLEAR:
				//Clear the screen in some way
				renderClearArea(data->extra1, data->color, &scrX, &scrY);
				if (render_mode == RENDER_SLOW)
					RenderFrame();
				free(data);
				break;
			case RENDER_SET_REGION:	//TODO dont assume valid
				//Set the current render area
				top_row = data->extra1;
				bot_row = data->extra2;
				
				scrX = 0;
				scrY = data->extra1;
				free(data);
				break;
			case RENDER_SETFONT:
				font_set = data->extra1;
				free(data);
				break;
			case RENDER_DRAW_CURRENT_POS:
				drawCurrentPos = data->extra1;
				free(data);
				break;
			default:
				smartPrint(&scrX, &scrY, COLOR_RED, COLOR_BLACK, "Bad Flag in Renderer", true);
				free(data);
				RenderFrame();
				break;
			}
		}
		
		
	}
	return 0;
}


//moveIfNeeded = true means that we rotate the current area through instead of clamping to the edge
void fixXandY(bool moveIfNeeded)
{
	if (scrX < 0) scrX = 0;
	if (scrX >= 80) scrX = 79;
	if (moveIfNeeded)
	{
		while (scrY < top_row)
		{
			shiftDown(&scrY);
//			scrY++;
		}
		while (scrY > bot_row)
		{
			shiftUp(&scrY);
//			scrY--;
		}
	}
	else
	{
		if (scrY < top_row) scrY = top_row;
		if (scrY > bot_row) scrY = bot_row;
	}
}
