#ifndef INCLUDED_PROTOCOL_IRC_H
#define INCLUDED_PROTOCOL_IRC_H

/* A thread which implements the irc protocol */
int ircProtocol(SceSize args, void *argp);

#endif

