#ifndef INCLUDED_PROTOCOL_TELNET_H
#define INCLUDED_PROTOCOL_TELNET_H

/* A thread which implements the telnet protocol */
int telnetProtocol(SceSize args, void *argp);

#endif

