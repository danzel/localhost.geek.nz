// WiFi Simple test app .03

#include "libs/std.h"
#include "libs/nlh.h" // net lib helper
#include "libs/p_sprint.h"

//////////////////////////////////////////////////////////////////////

//NOTE: kernel mode module flag and kernel mode thread are both required
PSP_MODULE_INFO("WIFI_TEST_APP", 0x1000, 1, 1); /* 0x1000 REQUIRED!!! */
PSP_MAIN_THREAD_ATTR(0); /* 0 REQUIRED!!! */
PSP_MAIN_THREAD_STACK_SIZE_KB(32); /* smaller stack for kernel thread */

/* messageBox for the UI Thread to message the Network Thread */
static SceUID networkMessagebox;

/* messageBox for the Network Thread to message the UI Thread */
static SceUID uiMessagebox;

/* Structure for the messages */
typedef struct _MyMessage {
	struct _MyMessage *link;  /* For internal use by the kernel */
	char* text;             /* Anything we would like to have */
} MyMessage;

int user_main(SceSize args, void* argp);
int interfaceThread(void);

#define putChar(x, y, c) pspDebugScreenPutChar((x)*7, (y)*8, 0x0FFFFFFF, c)
#define putCharC(x, y, color, c) pspDebugScreenPutChar((x)*7, (y)*8, color, c)

void putString(int x, int y, int c, char str[]) 
{
	int i = 0;
//	while(str[i] != '\0')

	while(str[i] != '\0')
	{
		putCharC(x,y,c,str[i]);
		i++;
		x++;
	}

}

static u32* g_vram_base = (u32*)(0x04000000+0x40000000);

void putPixel(int x, int y, int color)
{
	g_vram_base[x + y * 512] = color;
}

void drawLine(int x0, int y0, int x1, int y1, int color)
{
	#define SWAP(a, b) tmp = a; a = b; b = tmp;
	int x, y, e, dx, dy, tmp;
	if (x0 > x1) {
		SWAP(x0, x1);
		SWAP(y0, y1);
	}
	e = 0;
	x = x0;
	y = y0;
	dx = x1 - x0;
	dy = y1 - y0;
	if (dy >= 0) {
		if (dx >= dy) {
			for (x = x0; x <= x1; x++) {
				putPixel(x, y, color);
				if (2 * (e + dy) < dx) {
					e += dy;
				} else {
					y++;
					e += dy - dx;
				}
			}
		} else {
			for (y = y0; y <= y1; y++) {
				putPixel(x, y, color);
				if (2 * (e + dx) < dy) {
					e += dx;
				} else {
					x++;
					e += dx - dy;
				}
			}
		}
	} else {
		if (dx >= -dy) {
			for (x = x0; x <= x1; x++) {
				putPixel(x, y, color);
				if (2 * (e + dy) > -dx) {
					e += dy;
				} else {
					y--;
					e += dy + dx;
				}
			}
		} else {   	
			SWAP(x0, x1);
			SWAP(y0, y1);
			x = x0;
			dx = x1 - x0;
			dy = y1 - y0;
			for (y = y0; y <= y1; y++) {
				putPixel(x, y, color);
				if (2 * (e + dx) > -dy) {
					e += dx;
				} else {
					x--;
					e += dx + dy;
				}
			}
		}
	}
}


void initScreen()
{
	/* init the p-sprint main test/input screen */
	pspDebugScreenInit();
	//printf ("   left      up        right     square    triangle  circle\n\n");
	//printf ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n                p-sprint 0.50a - by Arwin van Arum");
	//drawLower(0);
	putString(31,1,0x0FFFFFFF,"PelDet - Danzel (thx Arwin)");
	drawLine(0,22,479,22,0x00000FFF);
	drawLine(0,242,479,242,0x00000FFF);
}



int main(void)
{
	// Kernel mode thread
	pspDebugScreenInit();

	printf("WiFi Simple .03\n");
	printf("  (by PspPet)\n");
	printf("\n");

	if (nlhLoadDrivers(&module_info) != 0)
	{
		printf("Driver load error\n");
		return 0;
	}

	// create user thread, tweek stack size here if necessary
	SceUID thid = sceKernelCreateThread("User Mode Thread", user_main,
			0x11, // default priority
			256 * 1024, // stack size (256KB is regular default)
			PSP_THREAD_ATTR_USER, NULL);

	// start user thread, then wait for it to do everything else
	sceKernelStartThread(thid, 0, NULL);
	sceKernelWaitThreadEnd(thid, NULL);

	sceKernelExitGame();
	return 0;
}

//////////////////////////////////////////////////////////////////////

static void RunTelnetClient(const char* szMyIPAddr);

int user_main(SceSize args, void* argp)
{
	// user mode thread does all the real work
	u32 err;
	int connectionConfig = -1;

	// nlhInit must be called from user thread for DHCP to work
	err = nlhInit();
	if (err != 0)
	{
		printf("WiFi Init error\n");
		printf("nlhInit returns $%x\n", err);
		printf("Please check Network Settings\n");
		sceKernelDelayThread(10*1000000); // 10sec to read before exit
		goto close_net;
	}

	// enumerate connections
#define MAX_PICK 10
	struct
	{
		int index;
		char name[64];
	} picks[MAX_PICK];
	int pick_count = 0;

	int iNetIndex;
	for (iNetIndex = 1; iNetIndex < 100; iNetIndex++) // skip the 0th connection
	{
		if (sceUtilityCheckNetParam(iNetIndex) != 0)
			break;  // no more
		sceUtilityGetNetParam(iNetIndex, 0, picks[pick_count].name);
		picks[pick_count].index = iNetIndex;
		pick_count++;
		if (pick_count >= MAX_PICK)
			break;  // no more room
	}

	if (pick_count == 0)
	{
		printf("No connections\n");
		printf("Please try Network Settings\n");
		sceKernelDelayThread(10*1000000); // 10sec to read before exit
		goto close_net;
	}

	printf("Found %d possible connections\n", pick_count);
#ifdef LATER
	if (pick_count > 1)
	{
		// customize user interface to let user pick
	}
#endif

	printf(" using the first one '%s'\n", picks[0].name);
	connectionConfig = picks[0].index;


	// Connect
	printf("using connection #%d\n", connectionConfig);
	err = sceNetApctlConnect(connectionConfig);
	if (err != 0)
	{
		printf("sceNetApctlConnect returns $%x\n", err);
		sceKernelDelayThread(10*1000000); // 10sec to read before exit
		goto close_net;
	}

	// Report status while waiting for connection to access point
	int stateLast = -1;
	printf("Connecting To Wifi...\n");
	while (1)
	{
		int state;
		err = sceNetApctlGetState(&state);
		if (err != 0)
		{
			printf("sceNetApctlGetState returns $%x\n", err);
			sceKernelDelayThread(10*1000000); // 10sec to read before exit
			goto close_connection;
		}
		if (state > stateLast)
		{
			printf("  connection state %d of 4\n", state);
			stateLast = state;
		}
		if (state == 4)
			break;  // connected with static IP

		// wait a little before polling again
		sceKernelDelayThread(50*1000); // 50ms
	}
	printf("Connected!\n");

	// connected, get my IPADDR and run telnet
	char szMyIPAddr[32];
	if (sceNetApctlGetInfo(8, szMyIPAddr) != 0)
		strcpy(szMyIPAddr, "unknown IP address");
	printf("my IPADDR = %s\n", szMyIPAddr);

	RunTelnetClient(szMyIPAddr);

	// all done

close_connection:
	err = sceNetApctlDisconnect();
	if (err != 0)
		printf("sceNetApctlDisconnect returns $%x\n", err);

close_net:

	nlhTerm();

	printf("Program exiting\n");
	sceKernelDelayThread(2*1000000); // 2sec to read any final status

	return 0;
}

//////////////////////////////////////////////////////////////////////
/*	Telnet Client

	Doesnt currently support anything like colors, shouldnt be too difficult to add :)
*/
static void RunTelnetClient(const char* szMyIPAddr)
{
	u32 err;
	SceUID interfaceThid; //Thread ID of the Interface
	
	// instructions
	pspDebugScreenClear();
	printf("Connecting to ....\n");
	printf("\n");

	{
		SOCKET sockListen;
		struct sockaddr_in addrListen;
		int error;

		sockListen = sceNetInetSocket(AF_INET, SOCK_STREAM, 0);
		if (sockListen <= 0)
		{
			printf("socket returned $%x\n", sockListen);
			goto done;
		}

			//Place we are connecting :)
		addrListen.sin_family = AF_INET;
		addrListen.sin_port = htons(3000);
		addrListen.sin_addr[0] = 206;
		addrListen.sin_addr[1] = 71;
		addrListen.sin_addr[2] = 72;
		addrListen.sin_addr[3] = 73;

		err = sceNetInetConnect(sockListen, &addrListen, sizeof(addrListen));
		if (err != 0)
		{
			printf("Unable to connect!\n");
			printf("connect returned $%x\n", err);
			printf("  errno=$%x\n", sceNetInetGetErrno());
			goto done;
		}
		
		//Alter Socket options to have a timeout
		u32 timeout = 1000000; // in microseconds == 1 sec
		err = sceNetInetSetsockopt(sockListen, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout));
		if (err != 0) //Failure
		{
			printf("set SO_RCVTIMEO failed\n");
			u32 data;
			int len;
			err = sceNetInetGetsockopt(sockListen, SOL_SOCKET, SO_RCVTIMEO,
				(char*)&data, &len);
			if (err == 0 && len == 4)
				printf("Get SO_RCVTIMEO = %d ($%x)\n", data, data);
		}
		
		//We are all Connected, fire up the interface Thread
		
			//Prepare Mailboxes for communication with other thread
		networkMessagebox = sceKernelCreateMbx("NT-MB", 0, 0);
		uiMessagebox = sceKernelCreateMbx("UI-MB", 0, 0);
		
		// PRIORITY FOR THIS THREAD??
		interfaceThid = sceKernelCreateThread("interfaceThread", interfaceThread, 11, 8192, THREAD_ATTR_USER, 0);
		sceKernelStartThread(interfaceThid, 0, NULL);
		
		while (1)
		{
				//Deal with Messages in the Box
			MyMessage* data;
			error = sceKernelPollMbx(networkMessagebox, (void*)&data);
			if(error < 0) {
				/* Nothing Arived */
			} else {
				//Received a Message
				//Send it over the Network.
				int len;
				char* myStr = malloc(sizeof(char) * strlen(data->text) + 3); // 3 = \r\n\0
				strcpy (myStr, data->text);
				len = strlen(myStr);
				myStr[len] = '\r';
				myStr[len+1] = '\n';
				myStr[len+2] = '\0';
				sceNetInetSend(sockListen, myStr, strlen(myStr), 0);
				
				free(myStr);
				free(data->text);
				data->text = 0;
				free(data);
			}

			//Receive anything on the Socket
			char buffer[10000];
			int cch;

			cch = sceNetInetRecv(sockListen, (u8*)buffer, sizeof(buffer)-1, 0);
			if (cch == 0)
				break;      // connection closed

			if (cch < 0)
			{
				int errno = sceNetInetGetErrno();
				if (errno == 11)
				{
					// recv timeout
				}
			}
			else
			{
				//successfull receive
				buffer[cch] = '\0';
				MyMessage* AMsg = malloc(sizeof(MyMessage));
				AMsg->text = strdup(buffer);
				sceKernelSendMbx(uiMessagebox, AMsg);
			}
			sceKernelDelayThread(3000);
		}
		
		//done lols
		printf("%s", "Connection Closed\r\n");
		
done:
		err = sceNetInetClose(sockListen);
		if (err != 0)
			printf("closesocket returned $%x\n", err);
	}
}

void smartPrint(int* scrX, int* scrY, const int color, char* inputStr)
{
//				putString(scrX, scrY, 0x000FFFFF, inputStr);
				//NewLine
//				scrX = 0; scrY++;
	
	bool needsMoving = false;
	int linesNeeded = 0;
	
	
		//Split the lines based on \n and 80chars
	
	int splitLinesSize = 0;
	char** splitLines = 0;
	
	int startpos = 0;
	int curSize = 0;
	
	int a = 0;
	for (a = 0; a < strlen(inputStr); a++)
	{
		curSize++;
		if (inputStr[a] == '\r' || inputStr[a] == '\n') //Try with a thing
		{
			curSize--;//miss the \n or \r
			
			if (curSize == 0)
			{
				startpos = a+1;
				curSize = 0;
			}
			else
			{
				splitLinesSize++;
				splitLines = realloc (splitLines, sizeof(char*)*splitLinesSize);
				
				splitLines[splitLinesSize-1] = malloc(sizeof(char)*(curSize+1));
				
				memcpy(splitLines[splitLinesSize-1], inputStr+startpos, curSize);
				splitLines[splitLinesSize-1][curSize] = '\0';
				
				//HAK
				if (curSize > 68)
					splitLines[splitLinesSize-1][68] = '\0';
				curSize = 0;
				startpos = a+1;
			}
		}
		if (curSize == 80)
		{
			splitLinesSize++;
			splitLines = realloc (splitLines, sizeof(char*)*splitLinesSize);
			splitLines[splitLinesSize-1] = malloc(sizeof(char)*81);
			memcpy(splitLines[splitLinesSize-1], inputStr+startpos, 80);
			splitLines[splitLinesSize-1][80] = '\0';
				
			//HAK
			if (curSize > 68)
				splitLines[splitLinesSize-1][68] = '\0';
			
			curSize = 0;
			startpos = a+1;
		}
	}
	if (curSize > 0)
	{
		splitLinesSize++;
		splitLines = realloc (splitLines, sizeof(char*)*splitLinesSize);
		
		splitLines[splitLinesSize-1] = malloc(sizeof(char)*(curSize+1));
		
		memcpy(splitLines[splitLinesSize-1], inputStr+startpos, curSize);
		splitLines[splitLinesSize-1][curSize] = '\0';
	}
	
	linesNeeded = splitLinesSize;
	
	if (*scrY + linesNeeded > 29)
	{
		needsMoving = true;
		linesNeeded = (*scrY + linesNeeded) - 29;
	}

//	printf("LM1:%i ", lineMoves);
			//char = 8px  lines = 26, 3 above
	//Move up X lines
	if (needsMoving)
	{
		//TODO if we need to move the whole screen off :| etc
		int x, y;
		for (y = 8*3; y < (8*29) - (8*linesNeeded); y++)
		{
			for (x = 0; x < 512; x++)
			{
	//			g_vram_base[x + y * 512] = 0x000000FF;//g_vram_base[x + (y*512) - (8*lineMoves*512) + (8*28*512)];
				g_vram_base[x + y * 512] = g_vram_base[x + (y*512) + (8*linesNeeded*512)];
				g_vram_base[x + (y*512) + (8*linesNeeded*512)] = 0x00000000;
	//			g_vram_base[x + (y*512) - (8*lineMoves*512) + (8*27*512)] = 0x00000000;
			}
		}
		*scrY -= linesNeeded;
	}
	//Print
	for (a = 0; a < splitLinesSize; a++)
	{
//		printf("%i) len:%i %ix%i\n", a, strlen(
		putString(*scrX, *scrY, color, splitLines[a]);
		free(splitLines[a]);
		(*scrY)++; *scrX=0;
	}
		free(splitLines);
}

int interfaceThread(void)
{
	int inputChar = 0;
	char inputStr[41];
	struct p_sp_Key myKey;
	int scrX = 0, scrY = 3;
	int prevgroup = 1;
	int iBlink = 0;
	
	inputStr[0] = '\0';


//	SetupCallbacks(); TODO
	initScreen();


	/* debug welcome message */
	sceDisplayWaitVblankStart(); 
	/* main loop waiting for input from pad*/

	while(1)
	{
		p_spReadKey(&myKey);
		if(myKey.keycode) //If we read a letter
		{
//			keyName[0] = myKey.keychar;
	//		keyName[1] = 0;

//			p_spGetKeycodeFriendlyName(myKey.keycode,keyName);
			
//			putString(2,31,0x0FFFFFFF,keyName);
			
			//Special Case Keys
			if (myKey.keychar == 13) //Enter
			{
					//Flush the input buffer to the screen! (and socket)
				
				//Write the Line on screen
//	printf("SP1:%i ", scrY);
				smartPrint(&scrX, &scrY, 0x000FFFFF, inputStr);
//	printf("SP2:%i ", scrY);

				//Send the String to the Network Thread.
				MyMessage* AMsg = malloc(sizeof(MyMessage));
				AMsg->text = strdup(inputStr);
				sceKernelSendMbx(networkMessagebox, AMsg);
				
				//Clear the input area..
				putString(0,31,0x0FFFFFFF,"                                        ");
				
				//Clear the input string
				inputStr[0] = '\0';
				inputChar = 0;
			}
			else if (myKey.keychar == 8 && inputChar != 0) //BackSpace
			{
				putCharC(inputChar,31,0x0FFFFFFF,' ');
				inputChar--;
				inputStr[inputChar] = '\0';
				putCharC(inputChar,31,0x0FFFFFFF,' ');
			}
			else //Normal char (Todo - special chars?)
			{
				if (inputChar != 40)
				{
					//Add the character to our buffer and draw it on the screens!
					inputStr[inputChar] = myKey.keychar;
					putCharC(inputChar,31,0x0FFFFFFF,myKey.keychar);
					inputChar++;
					inputStr[inputChar] = '\0';
					putCharC(inputChar,31,0x0FFFFFFF,' ');
				}
			}
		}
		
		if(myKey.keygroup!=prevgroup)//Changing KeyGroup
		{
			putString(50,31,0x0FFFFFFF,"                  ");
			switch(myKey.keygroup)
			{
			case 0:
				putString(50,31,0x0FFFFFFF,"Alphabet");
				break;
			case 1:
				putString(50,31,0x0FFFFFFF,"Numbers & F-Keys");
				break;
			case 2:
				putString(50,31,0x0FFFFFFF,"Control keys");
				break;
			case 3:
				putString(50,31,0x0FFFFFFF,"Custom 1");
				break;
			case 4:
				putString(50,31,0x0FFFFFFF,"Custom 2");
				break;
			case 5:
				putString(50,31,0x0FFFFFFF,"Custom 3");
				break;
			}
			prevgroup = myKey.keygroup;
		} 
		
		iBlink++;
		if(iBlink<20)
		{
			putCharC(inputChar,31,0x0FFFFFFF,'_');
		}
		else if(iBlink<40)
		{
			putCharC(inputChar,31,0x0FFFFFFF,' ');
		}
		else
		{
			iBlink=0;
		}
		
		//Receive Messages :)
		int error;
		MyMessage* data;
		error = sceKernelPollMbx(uiMessagebox, (void*)&data);
		if(error < 0) {
//			printf("MAIN: ERROR %08x\n", error);
			/* Sleep for a little while to give the message
			   a chance to arrive */
//			sceKernelDelayThread(300000);			
		} else {
//			printf("MAIN: got message: \"%s\"\n", ((MyMessage *)data)->text);
			int cln = strlen(data->text)-1;
			while (1)
			{
				if (data->text[cln] == '\n' || data->text[cln] == '\r')
					data->text[cln] = '\0';
				else
					break;
				cln--;
				if (cln == -1) break;
			}
			//Write the Line on screen
			smartPrint(&scrX, &scrY, 0x0FFFFFFF, data->text);
		}		

		sceDisplayWaitVblankStart(); 
		sceKernelDelayThread(3000);
	}
	return 0;
}
