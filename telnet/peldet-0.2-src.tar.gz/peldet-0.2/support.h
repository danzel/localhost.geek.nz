#ifndef INCLUDED_SUPPORT_H
#define INCLUDED_SUPPORT_H

//This file is licensed under the GPL V2
#include "gpl.txt"

#define putPixel(x,y,c) g_vram_base[(x)+(y)*512]=color;

void drawLine(int x0, int y0, int x1, int y1, int color);

#define putChar(x, y, c) pspDebugScreenPutChar((x)*7, (y)*8, 0x0FFFFFFF, c)
#define putCharC(x, y, color, c) pspDebugScreenPutChar((x)*7, (y)*8, color, c)

void putString(int x, int y, int c, char str[]);
void smartPrint(int* scrX, int* scrY, const int color, char* inputStr);

static u32* g_vram_base = (u32*)(0x04000000+0x40000000);


#define multiselect(x,y,picks,size,selected); \
		while (!done)\
		{\
			SceCtrlData pad;\
			bool onepressed = false;\
			int loop;\
				/*Print out current selection*/\
			pspDebugScreenSetXY(x, y);\
			printf("Chose one and press X\n");\
			for (loop = 0; loop < size; loop++)\
			{\
				if (selected == loop)\
					printf("> %s\n",picks[loop].name);\
				else\
					printf("  %s\n",picks[loop].name);\
			}\
				/*now loop on input, let it fall through to redraw, if it is X then break*/\
			while (!onepressed)/*While havent pressed a key*/\
			{\
				sceCtrlReadBufferPositive(&pad, 1); \
				onepressed = ( (pad.Buttons & PSP_CTRL_CROSS) ||\
								(pad.Buttons & PSP_CTRL_UP) ||\
								(pad.Buttons & PSP_CTRL_DOWN));\
			}\
			/*Find the key and change based on it*/\
			if (pad.Buttons & PSP_CTRL_CROSS) done = true;\
			if (pad.Buttons & PSP_CTRL_UP) selected = (selected + pick_count - 1) % pick_count;\
			if (pad.Buttons & PSP_CTRL_DOWN) selected = (selected+1) % pick_count;\
			while (onepressed)/*Wait for Key Release*/\
			{\
				sceCtrlReadBufferPositive(&pad, 1); \
				onepressed = ( (pad.Buttons & PSP_CTRL_CROSS) ||\
								(pad.Buttons & PSP_CTRL_UP) ||\
								(pad.Buttons & PSP_CTRL_DOWN));\
			}\
		}

#endif
