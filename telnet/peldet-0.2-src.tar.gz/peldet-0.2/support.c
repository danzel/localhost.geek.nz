//This file is licensed under the GPL V2
#include "gpl.txt"

#include "libs/std.h"
#include "support.h"

void drawLine(int x0, int y0, int x1, int y1, int color)
{
	#define SWAP(a, b) tmp = a; a = b; b = tmp;
	int x, y, e, dx, dy, tmp;
	if (x0 > x1) {
		SWAP(x0, x1);
		SWAP(y0, y1);
	}
	e = 0;
	x = x0;
	y = y0;
	dx = x1 - x0;
	dy = y1 - y0;
	if (dy >= 0) {
		if (dx >= dy) {
			for (x = x0; x <= x1; x++) {
				putPixel(x, y, color);
				if (2 * (e + dy) < dx) {
					e += dy;
				} else {
					y++;
					e += dy - dx;
				}
			}
		} else {
			for (y = y0; y <= y1; y++) {
				putPixel(x, y, color);
				if (2 * (e + dx) < dy) {
					e += dx;
				} else {
					x++;
					e += dx - dy;
				}
			}
		}
	} else {
		if (dx >= -dy) {
			for (x = x0; x <= x1; x++) {
				putPixel(x, y, color);
				if (2 * (e + dy) > -dx) {
					e += dy;
				} else {
					y--;
					e += dy + dx;
				}
			}
		} else {   	
			SWAP(x0, x1);
			SWAP(y0, y1);
			x = x0;
			dx = x1 - x0;
			dy = y1 - y0;
			for (y = y0; y <= y1; y++) {
				putPixel(x, y, color);
				if (2 * (e + dx) > -dy) {
					e += dx;
				} else {
					x--;
					e += dx + dy;
				}
			}
		}
	}
}


void putString(int x, int y, int c, char str[]) 
{
	int i = 0;
//	while(str[i] != '\0')

	while(str[i] != '\0')
	{
		putCharC(x,y,c,str[i]);
		i++;
		x++;
	}

}

void smartPrint(int* scrX, int* scrY, const int color, char* inputStr)
{
	int a = 0;
	for (a = 0; a < strlen(inputStr); a++)
	{
		//Possible shift up
		if (*scrY > 29)
		{
			int x, y;
			for (y = 0; y < 8*29; y++)
			{
				for (x = 0; x < 512; x++)
				{
					g_vram_base[x + y * 512] = g_vram_base[x + (y*512) + (8*512)];
					g_vram_base[x + (y*512) + (8*512)] = 0x00000000;
				}
			}
			*scrY -= 1;
		}
		
		
		if (inputStr[a] == '\r')
		{
			(*scrX)=0;
		}
		else if (inputStr[a] == '\n')
		{
			(*scrY)++;
		}
		else
		{
			putCharC(*scrX, *scrY, color, inputStr[a]);
			(*scrX)++;
		}
		
		//wrap
		if ((*scrX) > 67)
		{
			(*scrX) = 0;
			(*scrY) ++;
		}
//		sceDisplayWaitVblankStart(); 
	}
}
