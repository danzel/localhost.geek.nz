#ifndef INCLUDED_PIC_H
#define INCLUDED_PIC_H

//Save the place we are going to draw the image and draw the image there.
void pic_saveAndDraw();

//reload the saved area to the screen
void pic_restoreSaved();

//returns true if there is one saved at the moment
bool pic_isOneSaved();
#endif
