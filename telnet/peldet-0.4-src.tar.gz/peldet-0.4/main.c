// WiFi Simple test app .03

//This file is licensed under the GPL V2
#include "gpl.txt"

#include "global.h"

#include "libs/nlh.h" // net lib helper
#include "libs/p_sprint.h"


//////////////////////////////////////////////////////////////////////

//NOTE: kernel mode module flag and kernel mode thread are both required
PSP_MODULE_INFO("PELDET", 0x1000, 1, 1); /* 0x1000 REQUIRED!!! */
PSP_MAIN_THREAD_ATTR(0); /* 0 REQUIRED!!! */
PSP_MAIN_THREAD_STACK_SIZE_KB(32); /* smaller stack for kernel thread */

/* messageBox for the UI Thread to message the Network Thread */
static SceUID networkMessagebox;

int user_main(SceSize args, void* argp);
void networkThread(const char* szMyIPAddr);
int interfaceThread(SceSize args, void* argp);

/* Exit callback */
int exit_callback(int arg1, int arg2, void *common)
{
	sceKernelExitGame();

	return 0;
}

/* Callback thread */
int CallbackThread(SceSize args, void *argp)
{
	int cbid;

	cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
	sceKernelRegisterExitCallback(cbid);

	sceKernelSleepThreadCB();
	return 0;
}

/* Sets up the callback thread and returns its thread id */
int SetupCallbacks(void)
{
	int thid = 0;

	thid = sceKernelCreateThread("update_thread", CallbackThread, 0x10, 0xFA0, 0, 0);
	if(thid >= 0)
	{
		sceKernelStartThread(thid, 0, 0);
	}
	
	return thid;
}


void initScreen()
{
	/* init the p-sprint main screen */
//	pspDebugScreenInit();
	drawLine(0,242,479,242,0x00000FFF);
}

int main(void)
{
	// Kernel mode thread
	pspDebugScreenInit();
	

	if (nlhLoadDrivers(&module_info) != 0)
	{
		printf("Driver load error\n");
		return 0;
	}

	// create user thread, tweek stack size here if necessary
	SceUID thid = sceKernelCreateThread("User Mode Thread", user_main,
			0x11, // default priority
			256 * 1024, // stack size (256KB is regular default)
			PSP_THREAD_ATTR_USER, NULL);

	// start user thread, then wait for it to do everything else
	sceKernelStartThread(thid, 0, NULL);
	sceKernelWaitThreadEnd(thid, NULL);
	
	sceKernelExitGame();
	return 0;
}

//////////////////////////////////////////////////////////////////////


int user_main(SceSize args, void* argp)
{
	// user mode thread does all the real work
	u32 err;
	int connectionConfig = -1;
	char buffer[200];
	SetupCallbacks(); //This must be ran from a userspace thread, not sure why :O
	sceKernelDelayThread(100000); // Give the Thread time to run (0.1Sec)
	
	//Prepare Mailboxes for communication between threads
	networkMessagebox = sceKernelCreateMbx("NT-MB", 0, 0);
	renderMessagebox = sceKernelCreateMbx("UI-MB", 0, 0);
	
	//Boot the render thread, TODO: priority?
	SceUID renderthid = sceKernelCreateThread("Render Thread", renderThread, 0x11, 256*1024, PSP_THREAD_ATTR_USER, NULL);
	sceKernelStartThread(renderthid, 0, NULL);
	
	
	renderMain("peldet (PSP Telnet)\r\n", COLOR_WHITE);
	renderMain("Coded by Danzel, Using Wifi code from PSPPet and P-Sprint from Arwin\r\n", COLOR_WHITE);
	renderMain("\r\n", COLOR_WHITE);
		
	// nlhInit must be called from user thread for DHCP to work
	err = nlhInit();
	if (err != 0)
	{
		renderMain("WiFi Init error\r\n", COLOR_WHITE);
		sprintf(buffer,"nlhInit returns $%x\r\n", err);
		renderMain(buffer, COLOR_WHITE);
		renderMain("Please check Network Settings\r\n", COLOR_WHITE);
		sceKernelDelayThread(10*1000000); // 10sec to read before exit
		goto close_net;
	}

	// enumerate connections
#define MAX_PICK 10
	struct
	{
		int index;
		char name[64];
	} picks[MAX_PICK];
	int pick_count = 0;

	int iNetIndex;
	for (iNetIndex = 1; iNetIndex < 100; iNetIndex++) // skip the 0th connection
	{
		if (sceUtilityCheckNetParam(iNetIndex) != 0)
			break;  // no more
		sceUtilityGetNetParam(iNetIndex, 0, picks[pick_count].name);
		picks[pick_count].index = iNetIndex;
		pick_count++;
		if (pick_count >= MAX_PICK)
			break;  // no more room
	}

	if (pick_count == 0)
	{
		renderMain("No connections\r\n", COLOR_WHITE);
		renderMain("Please try Network Settings\r\n", COLOR_WHITE);
		sceKernelDelayThread(10*1000000); // 10sec to read before exit
		goto close_net;
	}

	sprintf(buffer,"Found %d possible connections\r\n", pick_count);
	renderMain(buffer, COLOR_WHITE);
	iNetIndex = 0;
	if (pick_count > 1)
	{
		bool done = 0;
		
		sceCtrlSetSamplingCycle(0);
		sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);

		multiselect(0,3,picks,pick_count,iNetIndex,"Choose a connection and press X");
	}

//	printf(" using %i) '%s'\n", iNetIndex, picks[iNetIndex].name);
	connectionConfig = picks[iNetIndex].index;


	// Connect
	sprintf(buffer, "using connection #%d '%s'\r\n", connectionConfig, picks[iNetIndex].name);
	renderMain(buffer, COLOR_WHITE);
	
	err = sceNetApctlConnect(connectionConfig);
	if (err != 0)
	{
		sprintf(buffer, "sceNetApctlConnect returns $%x\r\n", err);
		renderMain(buffer, COLOR_RED);
		sceKernelDelayThread(4*1000000); // 4sec to read before exit
		goto close_net;
	}

	// Report status while waiting for connection to access point
	int stateLast = -1;
	renderMain("Connecting To Wifi...\r\n", COLOR_WHITE);
	while (1)
	{
		int state;
		err = sceNetApctlGetState(&state);
		if (err != 0)
		{
			sprintf(buffer, "sceNetApctlGetState returns $%x\r\n", err);
			renderMain(buffer, COLOR_WHITE);
			sceKernelDelayThread(10*1000000); // 10sec to read before exit
			goto close_connection;
		}
		if (state != stateLast)
		{
			if (stateLast == 2 && state == 0)
			{
				renderMain("  Connecting to wifi Failed\r\n", COLOR_WHITE);
				goto close_net;
			}
			sprintf(buffer, "  connection state %d of 4\r\n", state);
			renderMain(buffer, COLOR_WHITE);
			stateLast = state;
		}
		if (state == 4)
			break;  // connected with static IP

		// wait a little before polling again
		sceKernelDelayThread(50*1000); // 50ms
	}
	
//	renderMain("Connected!\r\n", COLOR_WHITE);

	// connected, get my IPADDR and run telnet
	char szMyIPAddr[32];
	if (sceNetApctlGetInfo(8, szMyIPAddr) != 0)
		strcpy(szMyIPAddr, "unknown IP address");
//	sprintf(buffer, "my IPADDR = %s\r\n", szMyIPAddr);
//	renderMain(buffer, COLOR_WHITE);
	networkThread(szMyIPAddr);

	// all done

close_connection:
	err = sceNetApctlDisconnect();
	if (err != 0)
	{
		sprintf(buffer, "sceNetApctlDisconnect returns $%x\r\n", err);
		renderMain(buffer, COLOR_RED);
	}

close_net:

	nlhTerm();

	renderMain("Program exiting\r\n", COLOR_RED);
	sceKernelDelayThread(2*1000000); // 2sec to read any final status

	return 0;
}


//Ask the user for the IP and return a corresponding sockaddr_in
struct sockaddr_in getConnectionFromUser()
{
	struct sockaddr_in addrListen;
	addrListen.sin_family = AF_INET;
	
	int inputChar = 0;
	char inputStr[41];
	struct p_sp_Key myKey;
	int prevgroup = 1;
	int iBlink = 0;

	//Get it from the user...

	sceDisplayWaitVblankStart(); 
	
	#define MAX_FAVORITES 10
	//Show Favorites and allow Selection
	struct
	{
		short int addr[4];
		short int port;
		char name[40];
	} picks[MAX_FAVORITES];
	
	int pick_count = 0;
	int picked = 0;
	bool done = 0;
	FILE* fd;
	
	sprintf(picks[0].name,"Manually Enter Details");
	pick_count++;
	
	fd = fopen("ms0:/peldetfav.txt","r");
//	fd = sceIoOpen("ms0:/telnet", PSP_O_RDONLY, 0777);
	if(fd == 0)
	{
		renderMain("No Favorites Found", COLOR_WHITE);
		picked = 0;
	}
	else
	{
		int x = 1;
//		short int a,b,c,d,e;
	//	char[40] name;
		int ret;
		for (;x< MAX_FAVORITES; x++)
		{
			ret = fscanf(fd, "%hd %hd %hd %hd %hd %s", &picks[pick_count].addr[0], &picks[pick_count].addr[1], &picks[pick_count].addr[2], &picks[pick_count].addr[3], &picks[pick_count].port, picks[pick_count].name);
			
			if (ret == 6)
				pick_count++; //Add one;
			else
				break;//either
			
			//Skip newline
			fscanf(fd,"\r");
			fscanf(fd,"\n");
		}
		fclose(fd);
		/*
		10 15 10 11 10000 test local
		206 71 72 73 3000 ROD
		*/
		
		multiselect(0,3,picks,pick_count,picked, "Chose a favorite to connect to and press X");
	}
	if (picked != 0)
	{
		//User chose a favorite
		addrListen.sin_addr[0] = picks[picked].addr[0];
		addrListen.sin_addr[1] = picks[picked].addr[1];
		addrListen.sin_addr[2] = picks[picked].addr[2];
		addrListen.sin_addr[3] = picks[picked].addr[3];
		addrListen.sin_port = htons(picks[picked].port);
		return addrListen;
	}
	//If new then...
	renderMain("Input the ip and port to connect to in the form AAA BBB CCC CCC PORT\r\n", COLOR_WHITE);
	renderMain("P-Sprint is in number input mode\r\n", COLOR_WHITE);
	p_spSetActiveGroup(P_SP_KEYGROUP_NUMFN);
	
	/* main loop waiting for input from pad*/
	while(1)
	{
		p_spReadKey(&myKey);
		if(myKey.keycode) //If we read a letter
		{
			//Special Case Keys
			if (myKey.keychar == 13) //Enter
			{
				short int a,b,c,d,e;
				//Convert String to ip
				sscanf(inputStr, "%hd %hd %hd %hd %hd", &a, &b, &c, &d,&e);
				addrListen.sin_addr[0] = a;
				addrListen.sin_addr[1] = b;
				addrListen.sin_addr[2] = c;
				addrListen.sin_addr[3] = d;
				addrListen.sin_port = htons(e);
				
				p_spSetActiveGroup(P_SP_KEYGROUP_DEFAULT);
				return addrListen;
			}
			else if (myKey.keychar == 8 && inputChar != 0) //BackSpace
			{
				putCharC(inputChar,31,0x0FFFFFFF,' ');
				inputChar--;
				inputStr[inputChar] = '\0';
				putCharC(inputChar,31,0x0FFFFFFF,' ');
			}
			else //Normal char (Todo - Other special chars?)
			{
				if (inputChar != 40)
				{
					//Add the character to our buffer and draw it on the screens!
					inputStr[inputChar] = myKey.keychar;
					putCharC(inputChar,31,0x0FFFFFFF,myKey.keychar);
					inputChar++;
					inputStr[inputChar] = '\0';
					putCharC(inputChar,31,0x0FFFFFFF,' ');
				}
			}
		}
		
		//Changing KeyGroup
		if(myKey.keygroup!=prevgroup)
		{
			putString(50,31,0x0FFFFFFF,"                  ");
			switch(myKey.keygroup)
			{
			case 0:
				putString(50,31,0x0FFFFFFF,"Alphabet");
				break;
			case 1:
				putString(50,31,0x0FFFFFFF,"Numbers & F-Keys");
				break;
			case 2:
				putString(50,31,0x0FFFFFFF,"Control keys");
				break;
			case 3:
				putString(50,31,0x0FFFFFFF,"Custom 1");
				break;
			case 4:
				putString(50,31,0x0FFFFFFF,"Custom 2");
				break;
			case 5:
				putString(50,31,0x0FFFFFFF,"Custom 3");
				break;
			}
			prevgroup = myKey.keygroup;
		} 
		
		iBlink++;
		if(iBlink<20)
		{
			putCharC(inputChar,31,0x0FFFFFFF,'_');
		}
		else if(iBlink<40)
		{
			putCharC(inputChar,31,0x0FFFFFFF,' ');
		}
		else
		{
			iBlink=0;
		}
		sceDisplayWaitVblankStart(); 
		sceKernelDelayThread(3000);
	}

	//UM DAMN HOW DID WE GET HERE
	return addrListen;
}
//////////////////////////////////////////////////////////////////////
/*	Telnet Client

	Doesnt currently support anything like colors, shouldnt be too difficult to add :)
*/
void networkThread(const char* szMyIPAddr)
{
	u32 err;
	SceUID interfaceThid; //Thread ID of the Interface
	char buffer[200];
	
	// instructions
	renderReset();
	renderMain("Connected to Wifi! Where shall we telnet to?\r\n", COLOR_WHITE);
	renderMain("\r\n", COLOR_WHITE);

	{
		SOCKET sockListen;
		struct sockaddr_in addrListen;
		int error;

		sockListen = sceNetInetSocket(AF_INET, SOCK_STREAM, 0);
		if (sockListen <= 0)
		{
			pspDebugScreenSetTextColor(0x00000FFF);
			sprintf(buffer, "socket returned $%x\r\n", sockListen);
			renderMain(buffer, COLOR_WHITE);
			goto done;
		}

			//Place we are connecting :)
		
		//Get CON IP From User
		addrListen = getConnectionFromUser();
/*
//		IRC
		addrListen.sin_port = htons(6667);
		addrListen.sin_addr[0] = 66;
		addrListen.sin_addr[1] = 198;
		addrListen.sin_addr[2] = 80;
		addrListen.sin_addr[3] = 67;
*/

//		RoD
/*		addrListen.sin_port = htons(3000);
		addrListen.sin_addr[0] = 206;
		addrListen.sin_addr[1] = 71;
		addrListen.sin_addr[2] = 72;
		addrListen.sin_addr[3] = 73;
	*/	
		renderMain("Connecting...\r\n", COLOR_WHITE);
		
		
		err = sceNetInetConnect(sockListen, &addrListen, sizeof(addrListen));
		if (err != 0)
		{
			renderMain("Unable to connect!\r\n", COLOR_RED);
			
			switch(sceNetInetGetErrno())
			{
			case 0x74:
				renderMain("  Connection Timed out\r\n", COLOR_RED);
				break;
			case 0x6f:
				renderMain("  Connection Refused\r\n", COLOR_RED);
				break;
			default:
				sprintf(buffer, "connect returned $%x\r\n", err);
				renderMain(buffer, COLOR_RED);
				sprintf(buffer, "  errno=$%x\r\n", sceNetInetGetErrno());
				renderMain(buffer, COLOR_RED);
			}
			goto done;
		}
		
		//Alter Socket options to have a timeout
		u32 timeout = 1000000; // in microseconds == 1 sec
		err = sceNetInetSetsockopt(sockListen, SOL_SOCKET, SO_RCVTIMEO, (char*)&timeout, sizeof(timeout));
		if (err != 0) //Failure
		{
			renderMain("set SO_RCVTIMEO failed\r\n", COLOR_RED);
			u32 data;
			int len;
			err = sceNetInetGetsockopt(sockListen, SOL_SOCKET, SO_RCVTIMEO,
				(char*)&data, &len);
			if (err == 0 && len == 4)
			{
				sprintf(buffer,"Get SO_RCVTIMEO = %d ($%x)\r\n", data, data);
				renderMain(buffer, COLOR_WHITE);
			}
		}
		
		//We are all Connected, 
		
		
		// fire up the interface Thread (TODO: priority fine?)
		interfaceThid = sceKernelCreateThread("interfaceThread", interfaceThread, 11, 8192, THREAD_ATTR_USER, 0);
		sceKernelStartThread(interfaceThid, 0, NULL);
		
		while (1)
		{
				//Deal with Messages in the Box
			NetworkMsg* data;
			error = sceKernelPollMbx(networkMessagebox, (void*)&data);
			if(error < 0) {
				/* Nothing Arived */
			} else {
				//Received a Message
				//Send it over the Network.
				int len;
				char* myStr = malloc(sizeof(char) * strlen(data->text) + 3); // 3 = \r\n\0
				strcpy (myStr, data->text);
				len = strlen(myStr);
				myStr[len] = '\r';
				myStr[len+1] = '\n';
				myStr[len+2] = '\0';
				sceNetInetSend(sockListen, myStr, strlen(myStr), 0);
				
				free(myStr);
				free(data->text);
				data->text = 0;
				free(data);
			}

			//Receive anything on the Socket
			char buffer[10000];
			int cch;

			cch = sceNetInetRecv(sockListen, (u8*)buffer, sizeof(buffer)-1, 0);
			if (cch == 0)
				break;      // connection closed

			if (cch < 0)
			{
				int errno = sceNetInetGetErrno();
				if (errno == 11)
				{
					// recv timeout
				}
			}
			else
			{
				//successfull receive
				buffer[cch] = '\0';
				
				/* IRC HAX */
/*				if (buffer[0] == 'P' && buffer[1] == 'I' && buffer[2] == 'N' && buffer[3] == 'G')
				{
					//PING
					buffer[1] = 'o';
					buffer[cch] = '\r';
					buffer[cch+1] = '\n';
					buffer[cch+2] = '\0';
					MyMessage* AMsg = malloc(sizeof(MyMessage));
					AMsg->text = strdup(buffer);
					AMsg->color = 0x00FFFFFF;
					sceKernelSendMbx(networkMessagebox, AMsg);
				}
*/			/* END IRC HAX */
				
				renderMain(buffer, COLOR_WHITE);
			}
			sceKernelDelayThread(3000);
		}
		
		//Connection is lost
		
		//Post a message to the interface
		renderMain("Connection Closed\r\n", COLOR_RED);
		
		err = sceNetInetClose(sockListen);
		if (err != 0)
		{
			sprintf(buffer,"closesocket returned $%x\n", err);
			renderMain(buffer, COLOR_RED);
		}
		
		
		//Wait for the message to be processed
		SceKernelMbxInfo info;
		info.size = sizeof(info);
		do
		{
			sceKernelDelayThread(3000);
			sceKernelReferMbxStatus(renderMessagebox, &info);
		} while (info.numMessages > 0);
		
		//now give the user a 2 seconds to read
		sceKernelDelayThread(2*1000000);

done:
		//Try close the socket incase it isnt
		err = sceNetInetClose(sockListen);
		
	}
}



int interfaceThread(SceSize args, void *argp)
{
	int inputChar = 0;
	char inputStr[41];
	struct p_sp_Key myKey;
	int prevgroup = 1;
	int iBlink = 0;
	
	inputStr[0] = '\0';


//	SetupCallbacks(); TODO
	renderReset();\
	initScreen();


	/* debug welcome message */
//	sceDisplayWaitVblankStart(); 
	/* main loop waiting for input from pad*/

	while(1)
	{
		//See if we should redraw the pic YYY
		SceCtrlData pad;
		sceCtrlReadBufferPositive(&pad, 1);
		if (pad.Buttons & PSP_CTRL_RTRIGGER)
		{
			//Flip the Screen
			if (pic_isOneSaved())
				pic_restoreSaved();
			else
				pic_saveAndDraw();
			sceDisplayWaitVblankStart();
			//Spinlock untill released
			while (pad.Buttons & PSP_CTRL_RTRIGGER)
			{
				sceCtrlReadBufferPositive(&pad, 1);
				sceKernelDelayThread(5000);//5ms
			}
		}
		
		
		p_spReadKey(&myKey);
		if(myKey.keycode) //If we read a letter
		{
			//Special Case Keys
			if (myKey.keychar == 13) //Enter
			{
					//Flush the input buffer to the screen! (and socket)
				static char newLine[3] = {'\r','\n','\0'};
				//Write the Line on screen
				renderMain(inputStr, COLOR_YELLOW);
				renderMain(newLine, COLOR_YELLOW);
				
				//Send the String to the Network Thread.
				NetworkMsg* AMsg = malloc(sizeof(NetworkMsg));
				AMsg->text = strdup(inputStr);
				sceKernelSendMbx(networkMessagebox, AMsg);
				
				//Clear the input area..
				putString(0,31,0x0FFFFFFF,"                                        ");
				
				//Clear the input string
				inputStr[0] = '\0';
				inputChar = 0;
			}
			else if (myKey.keychar == 8) //BackSpace
			{
				if (inputChar != 0)
				{
					putCharC(inputChar,31,0x0FFFFFFF,' ');
					inputChar--;
					inputStr[inputChar] = '\0';
					putCharC(inputChar,31,0x0FFFFFFF,' ');
				}
			}
			else //Normal char (Todo - Other special chars?)
			{
				if (inputChar != 40 && myKey.keychar != 0)
				{
					//Add the character to our buffer and draw it on the screens!
					inputStr[inputChar] = myKey.keychar;
					putCharC(inputChar,31,0x0FFFFFFF,myKey.keychar);
					inputChar++;
					inputStr[inputChar] = '\0';
					putCharC(inputChar,31,0x0FFFFFFF,' ');
				}
			}
		}
		
		if(myKey.keygroup!=prevgroup)//Changing KeyGroup
		{
			putString(50,31,0x0FFFFFFF,"                  ");
			switch(myKey.keygroup)
			{
			case 0:
				putString(50,31,0x0FFFFFFF,"Alphabet");
				break;
			case 1:
				putString(50,31,0x0FFFFFFF,"Numbers & F-Keys");
				break;
			case 2:
				putString(50,31,0x0FFFFFFF,"Control keys");
				break;
			case 3:
				putString(50,31,0x0FFFFFFF,"Custom 1");
				break;
			case 4:
				putString(50,31,0x0FFFFFFF,"Custom 2");
				break;
			case 5:
				putString(50,31,0x0FFFFFFF,"Custom 3");
				break;
			}
			prevgroup = myKey.keygroup;
		} 
		
		iBlink++;
		if(iBlink<20)
		{
			putCharC(inputChar,31,0x0FFFFFFF,'_');
		}
		else if(iBlink<40)
		{
			putCharC(inputChar,31,0x0FFFFFFF,' ');
		}
		else
		{
			iBlink=0;
		}
		sceKernelDelayThread(3000);
	}
	return 0;
}
