#ifndef INCLUDED_RENDER_H
#define INCLUDED_RENDER_H

/* messageBox for the Network/UI Thread to message the Render Thread */
extern SceUID renderMessagebox;

int renderThread(SceSize args, void *argp);

//Add something to be rendered in the main render area
#define renderMain(string, textColor) {\
	RenderMsg* AMsg = malloc(sizeof(RenderMsg));\
	AMsg->text = strdup(string);\
	AMsg->color = textColor;\
	AMsg->flags = 0;\
	sceKernelSendMbx(renderMessagebox, AMsg);\
	}

#define renderReset() {\
	RenderMsg* AMsg = malloc(sizeof(RenderMsg));\
	AMsg->flags=1;\
	sceKernelSendMbx(renderMessagebox, AMsg);\
	}

#define renderGoto(pos) {\
	RenderMsg* AMsg = malloc(sizeof(RenderMsg));\
	AMsg->color=pos;\
	AMsg->flags=2;\
	sceKernelSendMbx(renderMessagebox, AMsg);\
	}

#define COLOR_WHITE  0x0fffffff
#define COLOR_RED    0x00000FFF
#define COLOR_YELLOW 0x0000FFFF


#endif
