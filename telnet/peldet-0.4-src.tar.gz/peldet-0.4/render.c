#define REALLY_RENDER
#include "global.h"


//This file is licensed under the GPL V2
#include "gpl.txt"

SceUID renderMessagebox;

int scrX = 0, scrY = 0;

int renderThread(SceSize args, void *argp)
{
//	int a = 0;
//	int msgsReceived = 0;
//	char b[10];
	while (1)
	{
/*		a++;
		a%=10;
		sprintf(b, "%i\n", a);
		putCharC(0,0,0x0FFFFFFF, b[0]);
		sprintf(b, "%i\n", renderMessagebox);
		int c = 0;
		for (c = 0; c < strlen(b); c++)
			putCharC(1+c,0, 0x0FFFFFFF, b[c]);*/
		//Receive Messages :)
		int error;
		RenderMsg* data;
		error = sceKernelPollMbx(renderMessagebox, (void*)&data);
		if(error < 0) {
			sceKernelDelayThread(1000);
		} else {
//			msgsReceived++;
			switch (data->flags)
			{
			case 0:
				//Write the Text on screen
				smartPrint(&scrX, &scrY, data->color, data->text);
				free(data->text);
				free(data);
				break;
			case 1:
				//Clear the screen
				scrX = 0;
				scrY = 0;
				int x, y;
				for(y=0;y<24*10;y++)
					for (x=0;x<480;x++)
						g_vram_base[x+(y*512)]=0;
				break;
			case 2:
				scrX = 0;
				scrY = data->color;
				break;
			default:
				smartPrint(&scrX, &scrY, COLOR_RED, "Bad Flag in Renderer");
			}
		}
		
		
	}
	return 0;
}
