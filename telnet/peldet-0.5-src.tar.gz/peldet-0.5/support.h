#ifndef INCLUDED_SUPPORT_H
#define INCLUDED_SUPPORT_H

//This file is licensed under the GPL V2
#include "gpl.txt"

#define putPixel(x,y,c) g_vram_base[(x)+(y)*512]=color;

void drawLine(int x0, int y0, int x1, int y1, int color);


void putString(int x, int y, int c, char str[]);
void smartPrint(int* scrX, int* scrY, const int color, char* inputStr);

static u32* g_vram_base = (u32*)(0x04000000+0x40000000);


#endif
