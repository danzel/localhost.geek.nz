#define REALLY_RENDER
#include "global.h"


//This file is licensed under the GPL V2
#include "gpl.txt"

SceUID renderMessagebox;
unsigned int __attribute__((aligned(16))) terminal_pixels_full[(512*272) + (512*270)];
unsigned int __attribute__((aligned(16))) *terminal_pixels;//[512*272];

unsigned int __attribute__((aligned(16))) *viewport;

unsigned int __attribute__((aligned(16))) list[262144];
int scrX = 0, scrY = 0;
void* framebuffer = 0;

//Render the Frame
#define RENDERFRAME(); sceGuStart(GU_DIRECT,list);\
			sceGuCopyImage(GU_PSM_8888,0,0,480,272,512,viewport,0,0,512,(void*)(0x04000000+(u32)framebuffer));\
			pic_draw(framebuffer);\
			sceKernelDcacheWritebackAll();\
			sceGuFinish();\
			sceGuSync(0,0);\
			framebuffer = sceGuSwapBuffers();

int renderThread(SceSize args, void *argp)
{
	int x_pos = 270;
	terminal_pixels = &terminal_pixels_full[(512*270)]; //Half way down the full backbuffer
	viewport = &terminal_pixels_full[(512*270)]; //Half way down the full backbuffer
	pic_init();
	
	while (1)
	{
		//Receive Messages :)
		int error;
		RenderMsg* data;
		error = sceKernelPollMbx(renderMessagebox, (void*)&data);
		if(error < 0) {
			sceKernelDelayThread(1000);
		} else {
			switch (data->flags)
			{
			case 0:
				//Write the Text on screen
				smartPrint(&scrX, &scrY, data->color, data->text, true);
				free(data->text);
				free(data);
				RENDERFRAME();
				break;
			case 1:
				//Clear the screen -- TODO _full?
				scrX = 0;
				scrY = 0;
				int x, y;
				for(y=0;y<24*10;y++)
					for (x=0;x<480;x++)
						terminal_pixels[x+(y*512)]=0;
				RENDERFRAME();
				break;
			case 2:
				//GOTO
				scrX = data->extra1;
				scrY = data->extra2;
				break;
			case 3:
				//redraw
				RENDERFRAME();
				break;
			case 4:
				//renderPrintString
				smartPrint(&data->extra1, &data->extra2, data->color, data->text, false);
				free(data->text);
				free(data);
				RENDERFRAME();
				break;
			case 5:
				//move up/down
				x_pos += data->extra1;
				if (x_pos > 270) x_pos = 270;
				if (x_pos < 0) x_pos = 0;
				viewport = &terminal_pixels_full[(512*x_pos)];
				free(data);
				RENDERFRAME();
				break;
				
			default:
				smartPrint(&scrX, &scrY, COLOR_RED, "Bad Flag in Renderer", true);
				RENDERFRAME();
			}
		}
		
		
	}
	return 0;
}
