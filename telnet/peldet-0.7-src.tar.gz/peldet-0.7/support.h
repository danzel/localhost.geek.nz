#ifndef INCLUDED_SUPPORT_H
#define INCLUDED_SUPPORT_H

//This file is licensed under the GPL V2
#include "gpl.txt"

//Draw a line from x0,y0 to x1,y1 with color color
void drawLine(int x0, int y0, int x1, int y1, int color);

void smartPrint(int* scrX, int* scrY, const int color, char* inputStr, bool lineWrap);

#endif
