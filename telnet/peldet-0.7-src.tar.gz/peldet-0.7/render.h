#ifndef INCLUDED_RENDER_H
#define INCLUDED_RENDER_H

/* messageBox for the Network/UI Thread to message the Render Thread */
extern SceUID renderMessagebox;

//Renderer Buffer
extern unsigned int __attribute__((aligned(16))) terminal_pixels_full[(512*272) + (512*270)];
extern unsigned int __attribute__((aligned(16))) *terminal_pixels;//[512*272];
extern unsigned int __attribute__((aligned(16))) list[262144];

extern void* framebuffer;

int renderThread(SceSize args, void *argp);

//Add something to be rendered in the main render area
#define renderMain(string, textColor) {\
	RenderMsg* AMsg = malloc(sizeof(RenderMsg));\
	AMsg->text = strdup(string);\
	AMsg->color = textColor;\
	AMsg->flags = 0;\
	sceKernelSendMbx(renderMessagebox, AMsg);\
	}

//Clear the main Render Area
#define renderReset() {\
	RenderMsg* AMsg = malloc(sizeof(RenderMsg));\
	AMsg->flags=1;\
	sceKernelSendMbx(renderMessagebox, AMsg);\
	}

//Move the cursor to x,y
#define renderGoto(x, y) {\
	RenderMsg* AMsg = malloc(sizeof(RenderMsg));\
	AMsg->flags=2;\
	AMsg->extra1=x;\
	AMsg->extra2=y;\
	sceKernelSendMbx(renderMessagebox, AMsg);\
	}

//Redraw the Current Screen
#define renderRedraw() {\
	RenderMsg* AMsg = malloc(sizeof(RenderMsg));\
	AMsg->flags=3;\
	sceKernelSendMbx(renderMessagebox, AMsg);\
	}

//Put a string at a position without moving the current Position or scrolling etc...
#define renderPutString(x, y, textColor, string) {\
	RenderMsg* AMsg = malloc(sizeof(RenderMsg));\
	AMsg->text = strdup(string);\
	AMsg->color = textColor;\
	AMsg->extra1=x;\
	AMsg->extra2=y;\
	AMsg->flags=4;\
	sceKernelSendMbx(renderMessagebox, AMsg);\
	}

//Change the currently rendered area of the screen
#define renderMove(xmov) {\
	RenderMsg* AMsg = malloc(sizeof(RenderMsg));\
	AMsg->flags=5;\
	AMsg->extra1=xmov;\
	sceKernelSendMbx(renderMessagebox, AMsg);\
	}


#define COLOR_WHITE  0x0FFFFFFF
#define COLOR_GREY   0x0AAAAAAA

#define COLOR_RED    0x00000FFF
#define COLOR_GREEN  0x0000AA00
#define COLOR_BLUE   0x00FF0000

#define COLOR_YELLOW 0x0000FFFF
#define COLOR_PURPLE 0x00FF0FFF
#endif
