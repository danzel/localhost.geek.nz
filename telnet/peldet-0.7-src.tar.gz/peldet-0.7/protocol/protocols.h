#include "telnet.h"
#include "irc.h"

#define protocols_count 2

struct {
	void* protocolMain;
	int stringCount; //Amount of additional strings that this protocol needs
	char* name;
} protocols[] =
{
	{ telnetProtocol, 0, "telnet" },
	{ ircProtocol,    2, "irc"}
};
