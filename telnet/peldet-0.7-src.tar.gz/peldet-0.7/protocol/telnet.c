#include "../global.h"
#include "telnet.h"
 
/* A thread which implements the telnet protocol */
int telnetProtocol(SceSize args, void *argp)
{
	char newLine[3] = {'\r','\n','\0'};
	ProtocolMsg* data;
	int error;
	
	while (1)
	{
	
		error = sceKernelReceiveMbx(protocolMessagebox, (void*)&data, NULL);
		if (error < 0)
		{
			//OH NO ERROR :(
			//tell renderer an error i guess....
			renderMain("TELNET IS DIED OHES NOES", COLOR_RED);
			return -1;
		}
		
		switch(data->from)
		{
		case FROM_NETWORK:
			renderMain(data->text, COLOR_WHITE);
			break;
		case FROM_USER:
			//Flush the input buffer to the screen! (and socket)
			
			//Write the Line on screen
			renderMain(data->text, COLOR_YELLOW);
			renderMain(newLine, COLOR_YELLOW);
			
			int len = strlen(data->text);
			data->text = realloc(data->text, len+3);
			data->text[len]   = '\r';
			data->text[len+1] = '\n';
			data->text[len+2] = '\0';
			
			//Send the String to the Network Thread.
			NetworkMsg* AMsg = malloc(sizeof(NetworkMsg));
			AMsg->text = strdup(data->text);
			sceKernelSendMbx(networkMessagebox, AMsg);
			
			break;
		}
		free(data->text);
		free(data);
	}
	
	//Should never happen
	return 0;
}
