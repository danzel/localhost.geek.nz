Instructions for use:

Move the analog stick to choose the square you are entering text from.
Press the button from /\[]XO in the direction of the character you want to type.

Hold R-Trigger for shift mode.
Hold L-Trigger to change to numbers input mode.
When in numbers mode holding shift changes to complete special characters input mode.

Digital up is delete, Digital down is 'enter'.

TODO:
Digital Left/Right will be move current input character left/right, allowing for fixing mistakes easily etc.

Leave feedback either here:
http://forums.qj.net/showthread.php?t=44058&page=6
or here:
http://localhost.geek.nz/?p=15

Danzel. danzelatlocalhostdotgeekdotnz