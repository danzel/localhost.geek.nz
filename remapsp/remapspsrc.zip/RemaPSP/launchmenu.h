#ifndef INCLUDED_LAUNCHMENU_H
#define INCLUDED_LAUNCHMENU_H

#include "main.h"

#ifdef BUILD_MENU

void launchMenu();

#endif //BUILD_MENU

#endif //INCLUDED_LAUNCHMENU_H
