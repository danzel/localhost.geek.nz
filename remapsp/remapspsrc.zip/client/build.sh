#!/bin/sh
gcc -Wall client.c -o client

