#ifndef BTTIME_H
#define BTTIME_H

#include <time.h>

extern time_t now;

#endif

