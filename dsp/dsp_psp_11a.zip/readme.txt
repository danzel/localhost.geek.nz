Defence Station Portable. 1.1
Fully Customisable Tower defence for the PSP.

Coded and drawn by Danzel - danzel@localhostdotgeekdotnz

Thanks:
Myself, JMC and the guys at SmarTrak for recording the noises.
Surreal for the build menu graphics.
Duey for telling me it doesn't work on his PSP (it still doesn't, lol)
Shazz for a bunch of good ideas :)
Inkscape, GIMP and Audacity devs, AWESOME SOFTWARE :D


PSP Controls:
Digital pad - Move selector.
x/O - Select/confirm
[]/^ - Cancel
Start - Build Menu
Select - Pause menu (Shows controls, level description)
R Trigger - Spawn next wave.

PC Controls:
Arrows - Move selector
Enter - Select/confirm
Space - Cancel / Build Menu
M - Pause Menu.
N - Spawn next wave.

NOTE: You can upgrade your towers, press x when hovering over one to select it, then X again to upgrade it.



If you want to make your own level, see the included leveldev.doc, 

FAQ:
Why isn't it 3d?
Because I drew all the gfx myself, and I'm not a 3d modeller :P
Will likely become 3d in the future if someone sends me lots of 3d models >_>

Why did it crash?
Dunno, if it is reproducable then I want to know!



Before sending me requests, read my todo available on my blog.

ChangeLog:
Add "How To Play" level.
Difficulty multiplier. (bigger number = more enemy HP)
Show tower stats while placing one.
Add "Save the house" mode.
Show range rings when upgrading towers (Yes, you can upgrade towers! :P select one on the map with X)
Show Wave XX/XX Text between waves.
Most game graphics customisable by level.
Fix loading levels made on windows.
Fix Quitting level in middle of wave stops player starting wave.
Fix points (Max 10 points / normal enemy, 40 points / boss. Quicker kill = more points)
