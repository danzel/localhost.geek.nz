Defence Station Portable.
Fully Customisable Tower defence for the PSP.

Coded and drawn by Danzel - danzel@localhostdotgeekdotnz

Thanks:
Myself, JMC and the guys at SmarTrak for recording the noises.
Surreal for the build menu graphics.
Duey for telling me it doesn't work on his PSP (it still doesn't, lol)
Inkscape, GIMP and Audacity devs, AWESOME SOFTWARE :D


PSP Controls:
Digital pad - Move selector.
x/O - Select/confirm
[]/^ - Cancel
Start - Build Menu
Select - Pause menu (Shows controls, level description)
R Trigger - Spawn next wave.

PC Controls:
Arrows - Move selector
Enter - Select/confirm
Space - Cancel / Build Menu
M - Pause Menu.
N - Spawn next wave.


If you want to make your own level, see the included leveldev.doc, 

FAQ:
How do I get rid of the neoflash splash?
Delete gfx/splash.png

Why isn't it 3d?
Because I drew all the gfx myself, and I'm not a 3d modeller :P
Will likely become 3d in the future if someone sends me lots of 3d models >_>

Why did it crash?
Dunno, if it is reproducable then I want to know!



Before sending me requests, read my todo list i've copied below:

Must Do
Difficulty levels (damage /= 1.5, speed, interest?)

Really Should Do
Show tower stats on mouse over
Deactivate menu (unload sprites, more memerysz) before full loading the level.
Buy lives on the menu. (Somewhere?....)
Tower selling. (75% is usual amount)

Probably won't do (Save for V2)
Fix InGame Menu, should return to previous state.
Investigte: Enemy Leave level sound?
Investigate: Reset controls on level start. (Stop drifting)
PSP Analog controls.
Fix tower placing to round better instead of truncating.
Make sidebar skinable per theme? - Including text color.
Make menu hideable.
Render ground enemies THEN flying enemies.
Render Range rings when upgrading towers.
Make Slow change with tower levels (time and length of effect)
Make centering on mouse more accurate (possible?)
Enemy deaths give points??? (What else should?)
Further Shot Types for Shot engine.

Really Probably won't do
Online score tracking! (long term addition)
Health bars? (long term addition, show only on life change?)
GlBits3 (More efficient rendering)
-- Investigate changing render functions to take floats instead of ints.

Things not likely todo because It requires file format changes for only a small gain

wave X bonus gold (level)
Multiple routes for enemies?..... (level if so)

Make between wave text show what wave u r on. -- Or not? Designer can always put it in the wave description.

Smart reminders things:
If you use an ordered insert into the instances lists, then when rendering it will be more efficient (render same sprite all at same time).
^^ Towers and shots can use this, enemies not really as we rely on their ordering